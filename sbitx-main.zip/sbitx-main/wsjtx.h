void wsjtx_start();
void wsjtx_slice();
