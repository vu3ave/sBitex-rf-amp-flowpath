void hamlib_start();
void hamlib_slice();

