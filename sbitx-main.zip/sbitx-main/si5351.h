void si5351_set_calibration(int32_t cal);
void si5351bx_init(); 
void si5351bx_setfreq(uint8_t clknum, uint32_t fout);
void si5351_reset();
void si5351a_clkoff(uint8_t clk);
