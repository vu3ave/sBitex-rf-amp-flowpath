void remote_write(char *message);
void remote_start();
void remote_slice();
