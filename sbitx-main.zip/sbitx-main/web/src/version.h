#define MG_VERSION "7.8"
